import javax.swing.*;
import java.awt.*;

public class StudentUI {

    public StudentUI() {
        JFrame frame = new JFrame("Student Dashboard");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 400);
        frame.setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel header = new JLabel("Submit Your Complaint");
        header.setFont(new Font("Arial", Font.BOLD, 20));
        header.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(header);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 20)));

        JLabel titleLabel = new JLabel("Title:");
        titleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        mainPanel.add(titleLabel);

        JTextField titleField = new JTextField();
        titleField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        mainPanel.add(titleField);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 10)));

        JLabel descLabel = new JLabel("Description:");
        descLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        mainPanel.add(descLabel);

        JTextArea complaintArea = new JTextArea(7, 20);
        complaintArea.setLineWrap(true);
        complaintArea.setWrapStyleWord(true);
        JScrollPane scrollPane = new JScrollPane(complaintArea);
        scrollPane.setAlignmentX(Component.LEFT_ALIGNMENT);
        mainPanel.add(scrollPane);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 20)));

        JButton submitBtn = new JButton("Submit Complaint");
        submitBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        submitBtn.addActionListener(e -> {
            String title = titleField.getText().trim();
            String desc = complaintArea.getText().trim();

            if(title.isEmpty() || desc.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Please enter both title and description!");
            } else {
                ComplaintController.submitComplaint(
                        ComplaintRepository.getComplaints().size() + 1,
                        title,
                        desc
                );
                JOptionPane.showMessageDialog(frame, "Complaint Submitted Successfully!");
                titleField.setText("");
                complaintArea.setText("");
            }
        });

        mainPanel.add(submitBtn);
        frame.add(mainPanel);
        frame.setVisible(true);
    }
}
