public class ComplaintController {
    public static void submitComplaint(int id, String title, String description) {
        Complaint c = new Complaint(id, title, description);
        ComplaintRepository.addComplaint(c);
    }
}
