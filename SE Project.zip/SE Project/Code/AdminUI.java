import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class AdminUI {

    public AdminUI() {
        JFrame frame = new JFrame("Admin Dashboard");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 400);
        frame.setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel header = new JLabel("All Submitted Complaints", SwingConstants.CENTER);
        header.setFont(new Font("Arial", Font.BOLD, 20));
        mainPanel.add(header, BorderLayout.NORTH);

        JTextArea complaintList = new JTextArea();
        complaintList.setEditable(false);
        complaintList.setLineWrap(true);
        complaintList.setWrapStyleWord(true);

        JScrollPane scrollPane = new JScrollPane(complaintList);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        // Load complaints
        ArrayList<Complaint> complaints = ComplaintRepository.getComplaints();
        StringBuilder sb = new StringBuilder();
        for(Complaint c : complaints) {
            sb.append("ID: ").append(c.getId())
                    .append("\nTitle: ").append(c.getTitle())
                    .append("\nDescription: ").append(c.getDescription())
                    .append("\nStatus: ").append(c.getStatus())
                    .append("\n-------------------------\n");
        }
        complaintList.setText(sb.toString());

        frame.add(mainPanel);
        frame.setVisible(true);
    }
}
