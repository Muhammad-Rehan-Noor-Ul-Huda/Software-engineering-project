import javax.swing.*;
import java.awt.*;

public class LoginUI {

    public LoginUI() {
        JFrame frame = new JFrame("UCMS Login");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));

        JLabel header = new JLabel("University Complaint Management System", SwingConstants.CENTER);
        header.setFont(new Font("Arial", Font.BOLD, 16));
        header.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(header);
        panel.add(Box.createRigidArea(new Dimension(0, 20)));

        JLabel userLabel = new JLabel("User ID:");
        userLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(userLabel);

        JTextField userField = new JTextField();
        userField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        panel.add(userField);
        panel.add(Box.createRigidArea(new Dimension(0, 10)));

        JLabel passLabel = new JLabel("Password:");
        passLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(passLabel);

        JPasswordField passField = new JPasswordField();
        passField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        panel.add(passField);
        panel.add(Box.createRigidArea(new Dimension(0, 20)));

        JButton loginBtn = new JButton("Login");
        loginBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(loginBtn);

        loginBtn.addActionListener(e -> {
            String userId = userField.getText().trim();
            String password = new String(passField.getPassword()).trim();

            User user = AuthController.login(userId, password);
            if(user != null) {
                JOptionPane.showMessageDialog(frame, "Login Successful! Role: " + user.getRole());
                frame.dispose();

                if(user.getRole().equalsIgnoreCase("Admin")) {
                    new AdminUI();
                } else {
                    new StudentUI();
                }
            } else {
                JOptionPane.showMessageDialog(frame, "Invalid UserID or Password!");
            }
        });

        frame.add(panel);
        frame.pack();
        frame.setLocationRelativeTo(null); // center frame
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        new LoginUI();
    }
}
