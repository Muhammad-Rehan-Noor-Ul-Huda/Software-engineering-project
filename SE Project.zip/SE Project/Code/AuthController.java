import java.util.HashMap;

public class AuthController {
    private static HashMap<String, String> users = new HashMap<>();
    private static HashMap<String, String> roles = new HashMap<>();

    static {
        users.put("admin", "admin123");
        users.put("student1", "stud123");
        users.put("student2", "stud456");

        roles.put("admin", "Admin");
        roles.put("student1", "Student");
        roles.put("student2", "Student");
    }

    public static User login(String userId, String password) {
        if(users.containsKey(userId) && users.get(userId).equals(password)) {
            return new User(userId, roles.get(userId));
        }
        return null;
    }
}
