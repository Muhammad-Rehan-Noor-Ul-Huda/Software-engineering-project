import java.util.ArrayList;

public class ComplaintRepository {
    private static final ArrayList<Complaint> complaints = new ArrayList<>();

    public static void addComplaint(Complaint c) {
        complaints.add(c);
    }

    public static ArrayList<Complaint> getComplaints() {
        return complaints;
    }
}
